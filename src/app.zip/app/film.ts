export class Film {
id: number;
name: string;
category: string;
director: string;
year: number;
status: boolean;
image: string;
}
